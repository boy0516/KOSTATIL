# aws-amplify-appsync-ourstory-workshop


## Overview of the Workshop

### Labs

* **Lab1: Setup Environment**
* **Lab2: Authentication**
* **Lab3: List Posts**
* **Lab4: Post Posts**
* **Lab5: Delete Posts**
* **Lab6: Likes**

### TODO

Like Notification and Speeding-up Listing will be updated.

### Cleanup

```shell
amplify delete
```